from selenium.webdriver.common.by import By
from Gas_Station.config.read_ini import *

website = \
    {
        'url': get_ini_value('environment', 'Prd')
    }

login_element = \
    {
        'keyword': (By.ID, 'kw'),
        'search': (By.ID, 'su'),
    }
